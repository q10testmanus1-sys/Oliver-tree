/* =========================================================
   OLIVER TREE — script.js
   ========================================================= */
(function(){
  "use strict";

  const WHATSAPP_NUMBER = "5511913453880";

  /* ---------- ICONS (inline SVG strings) ---------- */
  const ICONS = {
    monitor:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><rect x="4" y="5" width="24" height="17" rx="3" fill="currentColor" fill-opacity=".16"/><rect x="4" y="5" width="24" height="17" rx="3" stroke="currentColor" stroke-width="2"/><path d="M4 10.2h24" stroke="currentColor" stroke-width="2"/><circle cx="7.6" cy="7.6" r="1" fill="currentColor"/><circle cx="10.8" cy="7.6" r="1" fill="currentColor"/><rect x="12" y="26" width="8" height="2.4" rx="1.2" fill="currentColor"/><path d="M13 22l-1.6 4M19 22l1.6 4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    food:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><path d="M8 12h16l-1.4 14.2a2 2 0 0 1-2 1.8H11.4a2 2 0 0 1-2-1.8L8 12Z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 12v-2a4 4 0 1 1 8 0v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M12.5 17.5c1 1 6 1 7 0" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    doc:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><path d="M9 4h10l6 6v18H9V4Z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M19 4v6h6" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="17" cy="21" r="4.2" stroke="currentColor" stroke-width="2"/><path d="M17 18.6v1.7l1.3.9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    phone:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><rect x="8" y="3" width="16" height="26" rx="3.4" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2"/><rect x="11.5" y="8" width="4" height="4" rx="1" fill="currentColor"/><rect x="16.5" y="8" width="4" height="4" rx="1" fill="currentColor" fill-opacity=".55"/><rect x="11.5" y="13" width="4" height="4" rx="1" fill="currentColor" fill-opacity=".55"/><rect x="16.5" y="13" width="4" height="4" rx="1" fill="currentColor"/><path d="M14.5 25h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    palette:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><path d="M16 4C9 4 4 9.5 4 16s5 12 11 12c1.7 0 2.8-1.3 2.8-2.7 0-.8-.3-1.3-.6-1.8-.4-.5-.6-1-.6-1.7 0-1.3 1.1-2.4 2.4-2.4H22c3.3 0 6-2.7 6-6C28 8 22.6 4 16 4Z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="10" cy="15" r="1.6" fill="currentColor"/><circle cx="13" cy="10" r="1.6" fill="currentColor"/><circle cx="19.5" cy="9.5" r="1.6" fill="currentColor"/><circle cx="23" cy="14" r="1.6" fill="currentColor"/></svg>',
    camera:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><rect x="4" y="9" width="24" height="18" rx="3.6" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2"/><circle cx="16" cy="18" r="5.2" stroke="currentColor" stroke-width="2"/><circle cx="16" cy="18" r="2.2" fill="currentColor"/><path d="M11 9l1.8-3.2h6.4L21 9" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="23.5" cy="13" r="1.2" fill="currentColor"/></svg>',
    megaphone:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><path d="M4 13v6a1.6 1.6 0 0 0 1.6 1.6h2.6l9 5.2V6.2l-9 5.2H5.6A1.6 1.6 0 0 0 4 13Z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M22 11a6 6 0 0 1 0 10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M25.5 8a10.5 10.5 0 0 1 0 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" opacity=".55"/><path d="M11.5 20.5v3.6a2 2 0 0 0 4 0V22" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    cloud:'<svg width="30" height="30" viewBox="0 0 32 32" fill="none"><path d="M9.5 24a6 6 0 0 1-.6-11.98A7.4 7.4 0 0 1 23 11.6 5.4 5.4 0 0 1 22.5 24h-13Z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><rect x="12.5" y="16.5" width="8" height="3" rx="1" fill="currentColor"/><rect x="12.5" y="20.5" width="8" height="3" rx="1" fill="currentColor" fill-opacity=".55"/></svg>',
    image:'<svg width="30" height="30" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="2.4" stroke="currentColor" stroke-width="1.4"/><circle cx="8.5" cy="9.5" r="1.6" stroke="currentColor" stroke-width="1.4"/><path d="M3 16.5l5-5 4 4 3-3 6 6" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>'
  };

  const ICON_IMAGES = {
    sites: "assets/icons/sites.webp",
    ifood: "assets/icons/ifood.webp",
    cnpj: "assets/icons/cnpj.webp",
    apps: "assets/icons/apps.webp",
    design: "assets/icons/design.webp",
    instagram: "assets/icons/instagram.webp",
    marketing: "assets/icons/marketing.webp",
    hospedagem: "assets/icons/hospedagem.webp"
  };

  const PRAZO_OPTS = ["Urgente","1-2 semanas","1 mês","Sem pressa"];
  const ORCAMENTO_OPTS = ["R$ até 500","R$ 500-1500","R$ 1500-3000","R$ 3000+","A combinar"];
  const SIM_NAO = ["Sim","Não"];

  /* ---------- DATA: SERVICES + FORM FIELDS ---------- */
  const SERVICES = [
    {
      id:"sites", icon:"monitor", title:"Sites Profissionais", desc:"WordPress, Elementor, Landing Pages",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"empresa", label:"Nome da empresa/projeto", type:"text", required:true},
        {name:"tipo_site", label:"Que tipo de site você precisa?", type:"select", options:["Landing Page","Site Institucional","E-commerce","Blog","Portfólio","Outro"], required:true},
        {name:"detalhes", label:"Descreva seu projeto em detalhes (cores, referências, funcionalidades)", type:"textarea", required:true},
        {name:"dominio", label:"Você já tem domínio e hospedagem?", type:"select", options:SIM_NAO, required:true},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true},
        {name:"orcamento", label:"Orçamento estimado", type:"select", options:ORCAMENTO_OPTS, required:true}
      ]
    },
    {
      id:"ifood", icon:"food", title:"Configuração iFood", desc:"Cardápio, imagens, categorias",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"estabelecimento", label:"Nome do restaurante/estabelecimento", type:"text", required:true},
        {name:"cardapio", label:"Tipo de cozinha/cardápio", type:"text", required:true},
        {name:"conta_ifood", label:"Você já tem conta no iFood?", type:"select", options:SIM_NAO, required:true},
        {name:"fotos", label:"Já tem fotos profissionais dos pratos?", type:"select", options:SIM_NAO, required:true},
        {name:"detalhes", label:"Descrição do que precisa", type:"textarea", required:true},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true},
        {name:"orcamento", label:"Orçamento estimado", type:"select", options:ORCAMENTO_OPTS, required:true}
      ]
    },
    {
      id:"cnpj", icon:"doc", title:"CNPJ e MEI", desc:"Abertura rápida e segura",
      fields:[
        {name:"nome", label:"Seu nome completo", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"tipo_abertura", label:"Tipo de abertura", type:"select", options:["MEI","CNPJ Ltda","Alteração de dados","Outro"], required:true},
        {name:"atividade", label:"Atividade principal do negócio", type:"text", required:true},
        {name:"local", label:"Estado/Cidade", type:"text", required:true},
        {name:"possui_cnpj", label:"Já possui CNPJ?", type:"select", options:SIM_NAO, required:true},
        {name:"detalhes", label:"Descrição adicional", type:"textarea", required:false},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true}
      ]
    },
    {
      id:"apps", icon:"phone", title:"Aplicativos Mobile", desc:"FlutterFlow, PWA, Android/iOS",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"projeto", label:"Nome do projeto/app", type:"text", required:true},
        {name:"tipo_app", label:"Tipo de aplicativo", type:"select", options:["PWA","App Nativo Android","App Nativo iOS","Multiplataforma","Não sei, preciso de ajuda"], required:true},
        {name:"funcionalidades", label:"Funcionalidades desejadas", type:"textarea", required:true},
        {name:"publico", label:"Público-alvo", type:"text", required:true},
        {name:"referencias", label:"Tem referências visuais?", type:"select", options:SIM_NAO, required:true},
        {name:"ideia", label:"Descreva detalhadamente sua ideia", type:"textarea", required:true},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true},
        {name:"orcamento", label:"Orçamento estimado", type:"select", options:ORCAMENTO_OPTS, required:true}
      ]
    },
    {
      id:"design", icon:"palette", title:"Design e Marcas", desc:"Logos, identidade visual, flyers",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"marca", label:"Nome da marca/empresa", type:"text", required:true},
        {name:"tipo_servico", label:"Tipo de serviço", type:"select", options:["Logo","Identidade Visual Completa","Flyer","Banner","Cartão de Visita","Outro"], required:true},
        {name:"estilo", label:"Descreva o estilo desejado (cores, referências, moderno/clássico/minimalista)", type:"textarea", required:true},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true},
        {name:"orcamento", label:"Orçamento estimado", type:"select", options:ORCAMENTO_OPTS, required:true}
      ]
    },
    {
      id:"instagram", icon:"camera", title:"Artes para Instagram", desc:"Posts, stories, banners",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"instagram", label:"@ do Instagram", type:"text", required:true},
        {name:"tipo_arte", label:"Tipo de arte", type:"select", options:["Posts","Stories","Banners","Carrossel","Destaques","Pacote Completo"], required:true},
        {name:"quantidade", label:"Quantidade de peças", type:"select", options:["1-5","6-10","11-20","Mais de 20"], required:true},
        {name:"detalhes", label:"Descreva o que precisa", type:"textarea", required:true},
        {name:"identidade", label:"Tem identidade visual definida?", type:"select", options:SIM_NAO, required:true},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true},
        {name:"orcamento", label:"Orçamento estimado", type:"select", options:ORCAMENTO_OPTS, required:true}
      ]
    },
    {
      id:"marketing", icon:"megaphone", title:"Marketing Digital", desc:"Instagram profissional, Linktree",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"empresa", label:"Nome da empresa/marca", type:"text", required:true},
        {name:"instagram", label:"@ do Instagram (se tiver)", type:"text", required:false},
        {name:"tipo_servico", label:"Tipo de serviço", type:"select", options:["Criação de Instagram do zero","Organização de destaques","Planejamento de conteúdo","Link de apresentação/Linktree","Material de divulgação","Pacote completo"], required:true},
        {name:"objetivo", label:"Descreva seu objetivo", type:"textarea", required:true},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true},
        {name:"orcamento", label:"Orçamento estimado", type:"select", options:ORCAMENTO_OPTS, required:true}
      ]
    },
    {
      id:"hospedagem", icon:"cloud", title:"Hospedagem e Domínios", desc:"Configuração completa",
      fields:[
        {name:"nome", label:"Seu nome", type:"text", required:true},
        {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
        {name:"email", label:"E-mail", type:"text", required:true},
        {name:"dominio", label:"Nome do domínio desejado", type:"text", required:true},
        {name:"tipo_servico", label:"Tipo de serviço", type:"select", options:["Registro de domínio","Configuração de hospedagem","Transferência de domínio","Configuração de e-mail profissional","Outro"], required:true},
        {name:"detalhes", label:"Descrição adicional", type:"textarea", required:false},
        {name:"prazo", label:"Prazo desejado", type:"select", options:PRAZO_OPTS, required:true}
      ]
    }
  ];

  const GENERIC_FORM = {
    id:"generico", title:"Comece Agora", subtitle:"Me conte o que você precisa e eu retorno pelo WhatsApp em até 24h.",
    icon:"doc",
    fields:[
      {name:"servico", label:"Qual serviço você precisa?", type:"select", options:SERVICES.map(s=>s.title), required:true},
      {name:"detalhes", label:"Descreva detalhadamente o que você precisa", type:"textarea", required:true},
      {name:"prazo", label:"Qual o prazo desejado?", type:"select", options:PRAZO_OPTS, required:true},
      {name:"orcamento", label:"Qual seu orçamento estimado?", type:"select", options:ORCAMENTO_OPTS, required:true},
      {name:"nome", label:"Seu nome", type:"text", required:true},
      {name:"whatsapp", label:"WhatsApp", type:"text", required:true},
      {name:"email", label:"E-mail", type:"text", required:true},
      {name:"empresa", label:"Nome da empresa/projeto", type:"text", required:false}
    ]
  };

  const PROJECTS = [
    {id:"clcceo", title:"CLCCEO", desc:"Hub central de apps e serviços empresariais"},
    {id:"conexaodje", title:"Conexão DJE", desc:"Plataforma jurídica conectando você à Justiça"},
    {id:"fcdex", title:"FCDEX", desc:"Logística inteligente e rastreamento em tempo real"},
    {id:"vizim", title:"VIZIM", desc:"App de comunidade e vizinhança"},
    {id:"nobreza", title:"Nobreza", desc:"Clube exclusivo de experiências e benefícios"}
  ];

  /* ---------- RENDER: SERVICE CARDS ---------- */
  const servicesGrid = document.getElementById("services-grid");
  servicesGrid.innerHTML = SERVICES.map((s, i) => `
    <div class="service-card reveal" style="--delay:${(i % 4) * 60}ms">
      <div class="service-card-head">
        <div class="service-icon"><img src="${ICON_IMAGES[s.id]}" alt="" width="64" height="64"></div>
        <h3>${s.title}</h3>
      </div>
      <p>${s.desc}</p>
      <div class="service-card-foot">
        <span class="service-tag">0${i + 1} / 0${SERVICES.length}</span>
        <button class="service-request" data-service="${s.id}" type="button">
          Solicitar
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
      </div>
    </div>
  `).join("");

  /* ---------- RENDER: PORTFOLIO CAROUSEL ---------- */
  const track = document.getElementById("carousel-track");
  const dotsWrap = document.getElementById("carousel-dots");
  const PORTFOLIO_IMAGES = {
    clcceo: "assets/portfolio/clcceo.webp",
    conexaodje: "assets/portfolio/conexaodje.webp",
    fcdex: "assets/portfolio/fcdex.webp",
    vizim: "assets/portfolio/vizim.webp",
    nobreza: "assets/portfolio/nobreza.webp"
  };

  track.innerHTML = PROJECTS.map(p => `
    <div class="project-card">
      <div class="project-inner">
        <div class="project-thumb"><img src="${PORTFOLIO_IMAGES[p.id]}" alt="${p.title}"></div>
        <div class="project-body">
          <h3>${p.title}</h3>
          <p>${p.desc}</p>
        </div>
      </div>
    </div>
  `).join("");
  dotsWrap.innerHTML = PROJECTS.map((_,i) => `<button data-dot="${i}" aria-label="Ir para o projeto ${i+1}"></button>`).join("");

  /* ---------- CAROUSEL LOGIC ---------- */
  (function carousel(){
    const viewport = document.getElementById("carousel-viewport");
    const prevBtn = document.getElementById("carousel-prev");
    const nextBtn = document.getElementById("carousel-next");
    const dots = [...dotsWrap.querySelectorAll("button")];
    let index = 0, timer = null;

    function perView(){
      const w = viewport.offsetWidth;
      if (window.innerWidth >= 1080) return 3;
      if (window.innerWidth >= 760) return 2;
      return 1;
    }
    function maxIndex(){ return Math.max(0, PROJECTS.length - perView()); }
    function go(i){
      index = Math.max(0, Math.min(i, maxIndex()));
      const cardWidth = viewport.offsetWidth / perView();
      track.style.transform = `translateX(-${index * cardWidth}px)`;
      dots.forEach((d,di) => d.classList.toggle("active", di === index));
    }
    function next(){ go(index + 1 > maxIndex() ? 0 : index + 1); }
    function prev(){ go(index - 1 < 0 ? maxIndex() : index - 1); }
    function startAuto(){ stopAuto(); timer = setInterval(next, 4000); }
    function stopAuto(){ if (timer) clearInterval(timer); }

    nextBtn.addEventListener("click", () => { next(); startAuto(); });
    prevBtn.addEventListener("click", () => { prev(); startAuto(); });
    dots.forEach((d,i) => d.addEventListener("click", () => { go(i); startAuto(); }));
    viewport.addEventListener("mouseenter", stopAuto);
    viewport.addEventListener("mouseleave", startAuto);

    // touch swipe
    let touchX = null;
    viewport.addEventListener("touchstart", e => { touchX = e.touches[0].clientX; stopAuto(); }, {passive:true});
    viewport.addEventListener("touchend", e => {
      if (touchX === null) return;
      const dx = e.changedTouches[0].clientX - touchX;
      if (dx > 40) prev(); else if (dx < -40) next();
      touchX = null; startAuto();
    }, {passive:true});

    window.addEventListener("resize", () => go(index));
    go(0);
    startAuto();
  })();

  /* ---------- MODAL LOGIC ---------- */
  const overlay = document.getElementById("modal-overlay");
  const modalIcon = document.getElementById("modal-icon");
  const modalTitle = document.getElementById("modal-title");
  const modalSubtitle = document.getElementById("modal-subtitle");
  const modalFields = document.getElementById("modal-fields");
  const modalForm = document.getElementById("modal-form");
  const modalSuccess = document.getElementById("modal-success");
  let lastFocused = null;

  function fieldHTML(f){
    const req = f.required ? '<span class="req">*</span>' : '';
    const reqAttr = f.required ? "required" : "";
    let control = "";
    if (f.type === "textarea"){
      control = `<textarea name="${f.name}" ${reqAttr} rows="4"></textarea>`;
    } else if (f.type === "select"){
      control = `<select name="${f.name}" ${reqAttr}>
        <option value="" disabled selected>Selecione…</option>
        ${f.options.map(o => `<option value="${o}">${o}</option>`).join("")}
      </select>`;
    } else {
      control = `<input type="text" name="${f.name}" ${reqAttr} autocomplete="off">`;
    }
    return `<div class="field"><label>${f.label} ${req}</label>${control}</div>`;
  }

  function openModal(config){
    lastFocused = document.activeElement;
    modalIcon.innerHTML = ICONS[config.icon] || ICONS.doc;
    modalTitle.textContent = config.title;
    modalSubtitle.textContent = config.subtitle || "Conte os detalhes e eu retorno pelo WhatsApp.";
    modalFields.innerHTML = config.fields.map(fieldHTML).join("");
    modalForm.dataset.serviceTitle = config.title;
    modalForm.classList.remove("hide");
    modalSuccess.classList.remove("show");
    overlay.classList.add("open");
    document.body.style.overflow = "hidden";
    setTimeout(() => { const first = modalFields.querySelector("input,select,textarea"); if(first) first.focus(); }, 350);
  }
  function closeModal(){
    overlay.classList.remove("open");
    document.body.style.overflow = "";
    if (lastFocused) lastFocused.focus();
  }

  document.getElementById("modal-close").addEventListener("click", closeModal);
  overlay.addEventListener("click", e => { if (e.target === overlay) closeModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && overlay.classList.contains("open")) closeModal(); });

  // open triggers
  document.getElementById("btn-comece-agora").addEventListener("click", () => openModal(GENERIC_FORM));
  document.getElementById("btn-fale-comigo").addEventListener("click", () => openModal(GENERIC_FORM));
  servicesGrid.addEventListener("click", e => {
    const btn = e.target.closest("[data-service]");
    if (!btn) return;
    const service = SERVICES.find(s => s.id === btn.dataset.service);
    if (service) openModal({title:`Solicitar: ${service.title}`, subtitle:`Preencha os campos abaixo sobre ${service.title.toLowerCase()}.`, icon:service.icon, fields:service.fields});
  });

  // form submit -> validate -> build whatsapp message -> show success -> redirect
  modalForm.addEventListener("submit", function(e){
    e.preventDefault();
    const inputs = [...modalFields.querySelectorAll("input,select,textarea")];
    let valid = true;
    const lines = [`Olá, Oliver! Quero solicitar: *${modalForm.dataset.serviceTitle}*`, ""];

    inputs.forEach(inp => {
      inp.classList.add("touched");
      if (inp.hasAttribute("required") && !inp.value.trim()){
        valid = false;
      }
      if (inp.value.trim()){
        const label = inp.closest(".field").querySelector("label").textContent.replace("*","").trim();
        lines.push(`*${label}:* ${inp.value.trim()}`);
      }
    });

    if (!valid){
      const firstInvalid = inputs.find(i => i.hasAttribute("required") && !i.value.trim());
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    modalForm.classList.add("hide");
    modalSuccess.classList.add("show");

    const message = encodeURIComponent(lines.join("\n"));
    const waURL = `https://wa.me/${WHATSAPP_NUMBER}?text=${message}`;

    setTimeout(() => { window.open(waURL, "_blank"); }, 900);
    setTimeout(() => { closeModal(); modalForm.reset(); }, 2600);
  });

  /* ---------- HEADER SCROLL STATE ---------- */
  const header = document.getElementById("site-header");
  function onScroll(){ header.classList.toggle("scrolled", window.scrollY > 30); }
  document.addEventListener("scroll", onScroll, {passive:true});
  onScroll();

  /* ---------- MOBILE NAV ---------- */
  const navToggle = document.getElementById("nav-toggle");
  const mainNav = document.getElementById("main-nav");
  navToggle.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", open ? "true" : "false");
  });
  document.querySelectorAll("[data-nav]").forEach(a => a.addEventListener("click", () => {
    mainNav.classList.remove("open");
    navToggle.setAttribute("aria-expanded", "false");
  }));

  /* ---------- REVEAL ON SCROLL ---------- */
  const revealEls = document.querySelectorAll(".reveal");
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting){ entry.target.classList.add("in"); io.unobserve(entry.target); } });
  }, {threshold:.15});
  revealEls.forEach(el => io.observe(el));

  /* ---------- PHONE PARALLAX TILT ---------- */
  const phoneWrap = document.getElementById("phone-wrap");
  const heroVisual = document.querySelector(".hero-visual");
  if (phoneWrap && heroVisual && window.matchMedia("(hover:hover)").matches){
    heroVisual.addEventListener("mousemove", e => {
      const rect = heroVisual.getBoundingClientRect();
      const px = (e.clientX - rect.left) / rect.width - .5;
      const py = (e.clientY - rect.top) / rect.height - .5;
      phoneWrap.style.transform = `rotateY(${px*14}deg) rotateX(${-py*14}deg)`;
    });
    heroVisual.addEventListener("mouseleave", () => { phoneWrap.style.transform = "rotateY(0) rotateX(0)"; });
  }

  /* ---------- LOADER ---------- */
  window.addEventListener("load", () => {
    const loader = document.getElementById("loader");
    setTimeout(() => loader.classList.add("hidden"), 500);
  });

  /* ---------- BACKGROUND PARTICLES ---------- */
  (function fx(){
    const canvas = document.getElementById("fx-canvas");
    const ctx = canvas.getContext("2d");
    let w,h,particles;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function resize(){
      w = canvas.width = window.innerWidth;
      h = canvas.height = Math.max(window.innerHeight, document.body.scrollHeight);
    }
    function init(){
      resize();
      const count = Math.min(70, Math.floor(w / 24));
      particles = Array.from({length:count}, () => ({
        x: Math.random()*w, y: Math.random()*h,
        r: Math.random()*1.6 + .4,
        vy: -(Math.random()*.25 + .06),
        vx: (Math.random()-.5)*.12,
        a: Math.random()*.5 + .15
      }));
    }
    function tick(){
      ctx.clearRect(0,0,w,h);
      particles.forEach(p => {
        p.y += p.vy; p.x += p.vx;
        if (p.y < -10){ p.y = h + 10; p.x = Math.random()*w; }
        ctx.beginPath();
        ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
        ctx.fillStyle = `rgba(168,85,247,${p.a})`;
        ctx.shadowColor = "rgba(168,85,247,.8)";
        ctx.shadowBlur = 4;
        ctx.fill();
      });
      if (!reduced) requestAnimationFrame(tick);
    }
    init();
    tick();
    let resizeTimer;
    window.addEventListener("resize", () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(init, 200); });
  })();

})();
